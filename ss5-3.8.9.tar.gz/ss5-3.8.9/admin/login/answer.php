<?php
$q=$_GET["users"];

echo "<p>(ò) Result &ugrave:</p>";


echo "<p>Richiesta < ";
 echo   $q ;
 echo  " > inserita correttamente.</p>";
?> 
